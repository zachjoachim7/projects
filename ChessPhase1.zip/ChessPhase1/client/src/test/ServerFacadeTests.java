import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import ui.ServerFacade;


public class ServerFacadeTests {

    ServerFacade facade = new ServerFacade("http://localhost:8080");

    @Test
    public void positiveClearAppTest() {

    }

    @Test
    public void negativeClearAppTest() {

    }

    @Test
    public void positiveCreateGameTest() {

    }

    @Test
    public void negativeCreateGameTest() {

    }

    @Test
    public void positiveJoinGameTest() {

    }

    @Test
    public void negativeJoinGameTest() {

    }

    @Test
    public void positiveListTest() {

    }

    @Test
    public void negativeListTest() {

    }

    @Test
    public void positiveLogoutTest() {

    }

    @Test
    public void negativeLogoutTest() {

    }

    @Test
    public void positiveLoginTest() {

    }

    @Test
    public void negativeLoginTest() {

    }

    @Test
    public void positiveRegisterTest() {

    }

    @Test
    public void negativeRegisterTest() {

    }
}

