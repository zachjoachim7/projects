package requests;

public class ClearApplicationRequest {}
